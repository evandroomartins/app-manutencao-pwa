
import { useState } from "react";

const Button = ({ children, ...props }) => (
  <button style={{ padding: '10px', margin: '5px', width: '100%' }} {...props}>{children}</button>
);

const Input = (props) => (
  <input style={{ padding: '10px', marginBottom: '10px', width: '100%' }} {...props} />
);

const Card = ({ children }) => (
  <div style={{ border: '1px solid #ccc', borderRadius: '10px', padding: '15px' }}>{children}</div>
);

const CardContent = ({ children }) => <div>{children}</div>;

const Checkbox = ({ id, checked, onChange }) => (
  <input type="checkbox" id={id} checked={checked} onChange={onChange} />
);

function Login({ onLogin }) {
  const [nome, setNome] = useState("");
  const [cpf, setCpf] = useState("");

  return (
    <div>
      <h1>Entrar no App</h1>
      <Input placeholder="Nome completo" value={nome} onChange={(e) => setNome(e.target.value)} />
      <Input placeholder="CPF" value={cpf} onChange={(e) => setCpf(e.target.value)} />
      <Button onClick={onLogin}>Entrar</Button>
    </div>
  );
}

function TelaInicial({ onAgendar, onVerFila, onPagamento, onSuporte }) {
  return (
    <div>
      <h1>Bem-vindo!</h1>
      <Card>
        <CardContent>
          <p>Plano ativo: Sim</p>
          <p>Status do pagamento: Em dia</p>
          <p>Próximo atendimento: 14/05/2025 às 10h</p>
          <Button onClick={onAgendar}>Solicitar Atendimento</Button>
          <Button onClick={onVerFila}>Ver Fila de Atendimento</Button>
          <Button onClick={onPagamento}>Pagamento</Button>
          <Button onClick={onSuporte}>Suporte</Button>
        </CardContent>
      </Card>
    </div>
  );
}

function Agendamento({ onVoltar }) {
  const [categoria, setCategoria] = useState("");
  const [opcoesSelecionadas, setOpcoesSelecionadas] = useState([]);

  const opcoes = {
    eletrica: [
      "Resistência do chuveiro",
      "Tomadas não funcionam",
      "Quadro elétrico",
      "Iluminação",
      "Ventilador de teto parou",
    ],
    refrigeracao: [
      "Ar não gela",
      "Ar pingando",
      "Ar com código de erro",
      "Geladeira não gela",
      "Higienização anual",
    ],
    hidraulica: [
      "Torneira pingando",
      "Descarga vazando",
    ],
  };

  const handleCheck = (item) => {
    setOpcoesSelecionadas((prev) =>
      prev.includes(item) ? prev.filter((i) => i !== item) : [...prev, item]
    );
  };

  return (
    <div>
      <h1>Agendamento</h1>
      <Button onClick={() => setCategoria("eletrica")}>Elétrica</Button>
      <Button onClick={() => setCategoria("hidraulica")}>Hidráulica</Button>
      <Button onClick={() => setCategoria("refrigeracao")}>Refrigeração</Button>

      {categoria && (
        <Card>
          <CardContent>
            <h2>Problemas em {categoria}</h2>
            {opcoes[categoria].map((item) => (
              <div key={item}>
                <Checkbox
                  id={item}
                  checked={opcoesSelecionadas.includes(item)}
                  onChange={() => handleCheck(item)}
                />
                <label htmlFor={item}>{item}</label>
              </div>
            ))}
            <Button>Solicitar atendimento</Button>
            <Button onClick={onVoltar}>Voltar</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function FilaAtendimento({ onVoltar }) {
  return (
    <div>
      <h1>Fila de Atendimento</h1>
      <Card>
        <CardContent>
          <p>15/05/2025 - 14h - Confirmado</p>
          <p>17/05/2025 - 09h - Aguardando</p>
          <p>20/05/2025 - 16h - Concluído</p>
          <Button onClick={onVoltar}>Voltar</Button>
        </CardContent>
      </Card>
    </div>
  );
}

function Pagamento({ onVoltar }) {
  return (
    <div>
      <h1>Pagamento</h1>
      <p>Escolha a forma de pagamento:</p>
      <Button>Pix</Button>
      <Button>Cartão de Crédito</Button>
      <Button>Boleto</Button>
      <Button onClick={onVoltar}>Voltar</Button>
    </div>
  );
}

function Suporte({ onVoltar }) {
  return (
    <div>
      <h1>Suporte</h1>
      <p>Fale conosco pelo WhatsApp:</p>
      <a href="https://wa.me/5521999999999" target="_blank" rel="noopener noreferrer">
        <Button>Abrir WhatsApp</Button>
      </a>
      <Button onClick={onVoltar}>Voltar</Button>
    </div>
  );
}

export default function App() {
  const [logado, setLogado] = useState(false);
  const [tela, setTela] = useState("inicial");

  if (!logado) return <Login onLogin={() => setLogado(true)} />;

  switch (tela) {
    case "agendamento":
      return <Agendamento onVoltar={() => setTela("inicial")} />;
    case "fila":
      return <FilaAtendimento onVoltar={() => setTela("inicial")} />;
    case "pagamento":
      return <Pagamento onVoltar={() => setTela("inicial")} />;
    case "suporte":
      return <Suporte onVoltar={() => setTela("inicial")} />;
    default:
      return (
        <TelaInicial
          onAgendar={() => setTela("agendamento")}
          onVerFila={() => setTela("fila")}
          onPagamento={() => setTela("pagamento")}
          onSuporte={() => setTela("suporte")}
        />
      );
  }
}
