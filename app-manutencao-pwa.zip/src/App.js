import { useState } from "react";

const Button = ({ children, ...props }) => (
  <button style={{ padding: '10px', margin: '5px', width: '100%' }} {...props}>{children}</button>
);

const Input = (props) => (
  <input style={{ padding: '10px', marginBottom: '10px', width: '100%' }} {...props} />
);

const Card = ({ children }) => (
  <div style={{ border: '1px solid #ccc', borderRadius: '10px', padding: '15px' }}>{children}</div>
);

const CardContent = ({ children }) => <div>{children}</div>;

const Checkbox = ({ id, checked, onChange }) => (
  <input type="checkbox" id={id} checked={checked} onChange={onChange} />
);

// ... código reduzido para simplificação (você pode usar a versão completa que estava no projeto)
export default function App() {
  return <div><h1>App de Manutenção funcionando!</h1></div>;
}
